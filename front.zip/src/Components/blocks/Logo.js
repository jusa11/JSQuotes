const Logo = () => {
  return (
    <div className="logo">
      <img src="src/img/Logo.png" alt="Цитаты Джейсона Стетхема" />
      <p className="logo-text">цитаты джейсона стетхема</p>
    </div>
  );
};

export default Logo;
