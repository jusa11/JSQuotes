const userLevels = [
  { title: 'Сынок', amount: 0, level: 0 },
  {
    title: 'Браток',
    amount: 4,
    level: 1,
  },
  {
    title: 'Работяга',
    amount: 12,
    level: 2,
  },
  {
    title: 'Приближённый',
    amount: 17,
    level: 3,
  },
  { title: 'Авторитет', amount: 25, level: 4 },
  {
    title: 'Советник',
    amount: 31,
    level: 5,
  },
  {
    title: 'Отец',
    amount: 37,
    level: 6,
  },
  {
    title: 'Стэтхэм',
    amount: 42,
    level: 7,
  },
];

module.exports = userLevels;
