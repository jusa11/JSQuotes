const NotFound = () => {
  return (
    <div className="not-found-container">
      <h1>404</h1>
      <p>Страница не найдена</p>
    </div>
  );
};

export default NotFound;
