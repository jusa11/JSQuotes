const SharePage = () => {
  return (
    <div className="profile-content__main">
      <div className="dev-yet">В разработке</div>
    </div>
  );
};

export default SharePage;
